﻿namespace TFLCodingChallenge.Options
{
    public class TFLClientOptions
    {
        public string App_Key { get; set; }
        public string App_Id { get; set; }
        public string Endpoint { get; set; }

    }
}
